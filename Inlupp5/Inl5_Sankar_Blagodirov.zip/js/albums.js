// Vår data (musikalbums)
var persons = [
    {
        "firstname" : "FThe Wall",
        "lastname" : "LThe Wall",
        "personalnumber" : "PThe Wall"
     
    },
    {
        "firstname" : "The Wall",
        "lastname" : "The Wall",
        "personalnumber" : "The Wall"
    }
];
