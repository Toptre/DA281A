// Vår data (musikalbums)
var persons = [
    {
        "firstname" : "Test",
        "lastname" : "Testsson",
        "personalnumber" : "1234567890"
     
    },
    {
        "firstname" : "Anna",
        "lastname" : "Svensson",
        "personalnumber" : "9001101211"
    },
    {
        "firstname" : "Patrik",
        "lastname" : "Eriksson",
        "personalnumber" : "9201101211"
    },
    {
        "firstname" : "Peter",
        "lastname" : "Svensson",
        "personalnumber" : "9001101211"
    },
    {
        "firstname" : "Anna",
        "lastname" : "Karlsson",
        "personalnumber" : "9001101211"
    },
    {
        "firstname" : "Anna",
        "lastname" : "Svensson",
        "personalnumber" : "9001101211"
    },
    {
        "firstname" : "Anna",
        "lastname" : "Svensson",
        "personalnumber" : "9001101211"
    },
    {
        "firstname" : "Anna",
        "lastname" : "Svensson",
        "personalnumber" : "9001101211"
    },
    {
        "firstname" : "Anna",
        "lastname" : "Svensson",
        "personalnumber" : "9001101211"
    }
];
